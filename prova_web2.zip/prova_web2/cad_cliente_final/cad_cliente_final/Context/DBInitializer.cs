﻿using cad_cliente_final.Models;

namespace cad_cliente_final.Context
{
    public static class DBInitializer
    {
        public static void Seed(WebApplication app)
        {
            using (var serviceScope = app.Services.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetRequiredService<AppCont>();

                context.Database.EnsureCreated();

                // Verifica se já existem clientes no banco
                if (!context.InfoClientes.Any())
                {
                    // Adiciona uma lista de clientes e seus endereços
                    context.InfoClientes.AddRange(new List<Dados>
                    {
                       new Dados
                    {
                        Nome = "Lucas Oliveira",
                        Email = "lucas.oliveira@gmail.com",
                        Rua = "Rua das Palmeiras",
                        Numero = 101,
                        Cidade = "Salvador",
                        Estado = "BA",
                        Pais = "Brasil"
                    },
                    
                    new Dados
                    {
                        Nome = "Mariana Ribeiro",
                        Email = "mariana.ribeiro@gmail.com",
                        Rua = "Avenida Central",
                        Numero = 202,
                        Cidade = "Brasília",
                        Estado = "DF",
                        Pais = "Brasil"
                    },
                    
                    new Dados
                    {
                        Nome = "Felipe Costa",
                        Email = "felipe.costa@gmail.com",
                        Rua = "Travessa das Laranjeiras",
                        Numero = 303,
                        Cidade = "Porto Alegre",
                        Estado = "RS",
                        Pais = "Brasil"
                    },
                    
                    new Dados
                    {
                        Nome = "Carla Mendes",
                        Email = "carla.mendes@gmail.com",
                        Rua = "Rua do Sol",
                        Numero = 404,
                        Cidade = "Manaus",
                        Estado = "AM",
                        Pais = "Brasil"
                    },
                    
                    new Dados
                    {
                        Nome = "Rodrigo Almeida",
                        Email = "rodrigo.almeida@gmail.com",
                        Rua = "Avenida das Nações",
                        Numero = 505,
                        Cidade = "Recife",
                        Estado = "PE",
                        Pais = "Brasil"
                    }
                    
                    });

                    // Salva as mudanças no banco de dados
                    context.SaveChanges();
                }
            }
        }
    }
}

